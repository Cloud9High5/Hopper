import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.swing.JLabel;
import javax.swing.Timer;

public class BrewController {
	private BrewModel b;

	public BrewController(BrewModel b) {
		this.b = b;
	}
	
	/*public boolean implement(float batchSize,RecipeModel recipe) {
		if(batchSize<0) {
			return false;	
		}
		else {
			int flag=0;
			ResultSet getRid=MyDBUtil.Select("SELECT RecipeId FROM Recipe"+ RecipeModel.getName());
			int Rid=getRid.getInt("RecipeID");
			ResultSet getRi= MyDBUtil.Select("SELECT NAME, Amount from recipe "+ Rid);
			while (getRi.next()){
				String nameOfRi=getRi.getString("Name");
				int amountOfRi= getRi.getInt("Amount");
				ResultSet getAmountOfIngredient=MyDBUtil.Select("SELECT Name, Amount From ingredient "+nameOfRi);
				int amountOfIngredient=getAmountOfIngredient.getInt("Amount");
				if(amountOfRi>=amountOfIngredient) {
					continue;
				}else {
					flag=1;
					break;
				}
			}
			if(flag==0) {
				while(getRi.next()) {
					String nameOfRi=getRi.getString("Name");
					int amountOfRi=getRi.getInt("Amount");
					ResultSet getAmountOfIngredient=MyDBUtil.Select("SELECT Name, Amount from Ingredient "+nameOfRi);
					int amountOfIngredient=getAmountOfIngredient.getInt("Amount");
					int result= amountOfIngredient-amountOfRi;
					String s="Update Ingredient Set Amount= " + result+ "Where Name= " + nameOfRi;
					MyDBUtil.update(s);
					return true;
				}
			}
			return false;
		}
	}*/
	public static void setTimer(JLabel time){
		final JLabel varTime = time;
		Timer timeAction = new Timer(1000, new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				long timemillis = System.currentTimeMillis();
				SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
				varTime.setText(df.format(new Date(timemillis)));
			}
		});
		timeAction.start();;
	}
}
