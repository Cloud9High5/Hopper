import java.awt.Color;
import java.awt.Font;
import java.awt.SystemColor;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.AbstractListModel;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.ScrollPaneConstants;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;

public class NoteView extends JFrame {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	public NoteView(NoteModel m, NoteController c) {
		setResizable(false);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 1048, 646);
		setTitle("note");
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JButton buttonBack = new JButton("Home");
		buttonBack.setFont(new Font("Bahnschrift", Font.BOLD, 14));
		buttonBack.setBounds(902, 559, 93, 23);
		contentPane.add(buttonBack);
		
		JLabel lblNewLabel_1 = new JLabel("Note");
		lblNewLabel_1.setBounds(279, 0, 484, 123);
		contentPane.add(lblNewLabel_1);
		lblNewLabel_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1.setForeground(Color.ORANGE);
		lblNewLabel_1.setFont(new Font("Bahnschrift", Font.BOLD | Font.ITALIC, 50));
		
		JButton btnAdd = new JButton("Update");
		btnAdd.setFont(new Font("Bahnschrift", Font.BOLD, 19));
		btnAdd.setBounds(175, 435, 156, 51);
		contentPane.add(btnAdd);
		
		JButton btnDelete = new JButton("Delete");
		btnDelete.setFont(new Font("Bahnschrift", Font.BOLD, 19));
		btnDelete.setBounds(712, 435, 156, 51);
		contentPane.add(btnDelete);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(104, 214, 834, 168);
		contentPane.add(scrollPane);
		scrollPane.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
		
		JList list_1 = new JList();
		list_1.setFont(new Font("Bahnschrift", Font.BOLD, 12));
		list_1.setModel(new AbstractListModel() {
			String[] values = new String[] {"example", "example", "example", "example", "example", "example", "example", "example", "example", "example", "example", "example", "example"};
			public int getSize() {
				return values.length;
			}
			public Object getElementAt(int index) {
				return values[index];
			}
		});
		list_1.setSelectedIndex(4);
		scrollPane.setViewportView(list_1);
		
		JLabel lblIngredient = new JLabel("Notes list:");
		lblIngredient.setBounds(104, 151, 93, 26);
		contentPane.add(lblIngredient);
		lblIngredient.setHorizontalAlignment(SwingConstants.CENTER);
		lblIngredient.setForeground(SystemColor.textInactiveText);
		lblIngredient.setFont(new Font("Bahnschrift", Font.BOLD, 17));
		this.setVisible(true);
		buttonBack.addActionListener(new ActionListener() {
			private HomeModel hm;
			private HomeController hc;

			@Override
				public void actionPerformed(ActionEvent e) {
				 // Controller decides what the click means.
				dispose();
				new HomeView(hm, hc);
				}
			});
		btnAdd.addActionListener(new ActionListener() {
			private NoteModel nm;
			private NoteController nc;

			@Override
				public void actionPerformed(ActionEvent e) {
				 // Controller decides what the click means.
				new NoteViewUpdate(nm, nc);
				}
			});
		btnDelete.addActionListener(new ActionListener() {
			private NoteModel nm;
			private NoteController nc;

			@Override
				public void actionPerformed(ActionEvent e) {
				MyDBUtil.insert(new NoteModel("eq4","asdasdadasdasd"));
				}
			});
	}
	
}
