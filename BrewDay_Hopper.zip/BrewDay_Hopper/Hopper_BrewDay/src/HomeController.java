
public class HomeController {
	private HomeModel m;
	
	public HomeController(HomeModel m) {
		this.m = m;
	}
}
