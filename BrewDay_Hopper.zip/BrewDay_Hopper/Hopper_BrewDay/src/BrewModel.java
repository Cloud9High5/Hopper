import java.text.SimpleDateFormat;
import java.util.Date;

import java.sql.ResultSet;
import java.util.Date;

public class BrewModel {
	private float batchSize;
	private Date date;
	private Date time;
	
	private NoteModel note;
	private RecipeModel recipe;
	private storageIngredient ingredient;
	
	public BrewModel(float batchSize, RecipeModel recipe) {
		if(batchSize>0) {
			this.batchSize=batchSize;
			this.date=new Date(System.currentTimeMillis());
			this.recipe=recipe;
		}
	}

	public float getBatchSize() {
		return batchSize;
	}
	public void setBatchSize(float batchSize) {
		this.batchSize = batchSize;
	}
	
}

