
import java.util.ArrayList;


//Some features of this class:
//The number of names and amounts must be the same.

public class IngredientModel {
	private ArrayList<String> name= new ArrayList<String>(); 
	private ArrayList<Double> amount = new ArrayList<Double>();
	private ArrayList<String> unit= new ArrayList<String>(); 
	private IngredientView v;
	
	//constructors
	public IngredientModel(ArrayList<String> name, ArrayList<Double> amount, ArrayList<String> unit) {
		this.name = name;
		this.amount = amount;
		this.unit = unit;
	}
	public ArrayList<String> getName(){
		return name;
	}
	public void setName(ArrayList<String> name) {
		this.name = name;
	}
	public ArrayList<Double> getAmount(){
		return amount;
	}
	public void setAmount(ArrayList<Double> amount) {
		this.amount = amount;
	}
	public ArrayList<String> getUnit(){
		return unit;
	}
	public void setUnit(ArrayList<String> unit) {
		this.unit = unit;
	}
}
