
import java.util.ArrayList;


//Some features of this class:
//The number of names and amounts must be the same.

public class IngredientModel {
	private String name= new String(); 
	private Double amount ;
	private String unit= new String(); 
	private IngredientView v;
	
	//constructors
	public IngredientModel(String name, Double amount, String unit) {
		this.name = name;
		this.amount = amount;
		this.unit = unit;
	}
	public String getName(){
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Double getAmount(){
		return amount;
	}
	public void setAmount(Double amount) {
		this.amount = amount;
	}
	public String getUnit(){
		return unit;
	}
	public void setUnit(String unit) {
		this.unit = unit;
	}
}
