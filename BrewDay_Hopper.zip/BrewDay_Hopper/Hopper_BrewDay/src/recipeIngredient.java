
import java.util.ArrayList;

public class recipeIngredient extends IngredientModel{

	public recipeIngredient(String name, Double amount, String unit) {
		super(name, amount, unit);
		// TODO Auto-generated constructor stub
	}

	//constructors
	/*public recipeIngredient() {
		super();
		
	}
	
	public recipeIngredient(ArrayList<String> name, ArrayList<Double> amount, ArrayList<String> unit) {
		super(name,amount,unit);
	}
	
	
	//update
	public int updateAmount(String name,Double amount) {
		
		return super.updateAmount(name, amount);
	}
	
	
	public int updateUnit(String unit) {
			
		return super.updateUnit(unit);
	}
	
	//add and delete
	
	public int addIngredient(String name,Double amount, String unit) {
			
		return super.addIngredient(name, amount, unit);
	}
	public int deleteIngredient(String name) {
		
		return super.deleteIngredient(name);
	}
	
	//get
	
	public int getAmount(ArrayList<Double> amount) {
		
		return super.getAmount(amount);
	}
	public int getName(ArrayList<String> name) {
		
		return super.getName(name);
	}
	public int getUnit(ArrayList<String> unit) {
		
		return super.getUnit(unit);
	}
	
	//get amount by name
	public Double getAmountbyName(String name) {

		return super.getAmountbyName(name);
	}
		*/
	
}
