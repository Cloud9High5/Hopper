import java.util.ArrayList;

public class IngredientController {
	private IngredientModel m;
	
public IngredientController(IngredientModel m) {
		this.m = m;
	}
	
	public String addName(String name) {
		m.getName().add(name);
		return name;
	}
	
	public Double addAmount(Double amount) {
		m.getAmount().add(amount);
		return amount;
	}
	
	public String addUnit(String unit) {
		m.getUnit().add(unit);
		return unit;
	}
	
}
