import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;

public class IngredientController {
	private IngredientModel m;
	
public IngredientController(IngredientModel m) {
		this.m = m;
	}
	
	/*public String addName(String name) {
		m.getName().add(name);
		return name;
	}
	
	public Double addAmount(Double amount) {
		m.getAmount().add(amount);
		return amount;
	}
	
	public String addUnit(String unit) {
		m.setUnit()unit;
		return unit;
	}*/
	public static int setAmount(String name,Double amount,String unit) {
		
		
		//convert string into amount
		
		Connection conn = MyDBUtil.getConn();
	    int i = 0;
	    
	    String sql = "update ingredient set Amount='"+amount +"', Unit='"+unit+"' where Name='" + name + "'";
	    
	    PreparedStatement pstmt;
	    try {
	        pstmt = (PreparedStatement) conn.prepareStatement(sql);
	        
	        i = pstmt.executeUpdate();
	        pstmt.close();
	        conn.close();
	    } catch (SQLException e) {
	        e.printStackTrace();
	    }
	    return i;
	}
	
}
