
import java.util.ArrayList;
public class RecipeModel {
	private ArrayList<String> name= new ArrayList<String>(); 
	private ArrayList<Double> quantity = new ArrayList<Double>();
	private ArrayList<String> unit= new ArrayList<String>(); 
	
	public RecipeModel(ArrayList<String> name, ArrayList<Double> quantity, ArrayList<String> unit) {
		this.name = name;
		this.quantity = quantity;
		this.unit = unit;
	}
	public ArrayList<String> getName(){
		return name;
	}
	public void setName(ArrayList<String> name) {
		this.name = name;
	}
	public ArrayList<Double> getQuantity(){
		return quantity;
	}
	public void setQuantity(ArrayList<Double> quantity) {
		this.quantity = quantity;
	}
	public ArrayList<String> getUnit(){
		return unit;
	}
	public void setUnit(ArrayList<String> unit) {
		this.unit = unit;
	}
}
