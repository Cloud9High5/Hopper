
public class RecipeModel {
	private String name;
	private Double waterQuantity;
	private Double maltQuantity;
	private Double hopQuantity;
	private Double yeastQuantity;
	private Double sugarQuantity;
	private Double additiveQuantity;
	
	public RecipeModel(String name, Double waterQuantity, Double maltQuantity, Double hopQuantity, Double yeastQuantity, Double sugarQuantity, Double additiveQuantity) {
		this.name = name;
		this.waterQuantity = waterQuantity;
		this.maltQuantity = waterQuantity;
		this.hopQuantity = hopQuantity;
		this.yeastQuantity = yeastQuantity;
		this.sugarQuantity = sugarQuantity;
		this.additiveQuantity = additiveQuantity;
	}
	public String getName(){
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Double getWaterQuantity(){
		return waterQuantity;
	}
	public void setWaterQuantity(Double waterQuantity) {
		this.waterQuantity = waterQuantity;
	}
	public Double getMaltQuantity(){
		return maltQuantity;
	}
	public void setMaltQuantity(Double maltQuantity) {
		this.maltQuantity = maltQuantity;
	}
	public Double getHopQuantity(){
		return hopQuantity;
	}
	public void setHopQuantity(Double hopQuantity){
		this.waterQuantity = hopQuantity;
	}
	public Double getYeastQuantity(){
		return yeastQuantity;
	}
	public void setYeastQuantity(Double yeastQuantity) {
		this.yeastQuantity = yeastQuantity;
	}
	public Double getSugarQuantity(){
		return sugarQuantity;
	}
	public void setSugarQuantity(Double sugarQuantity) {
		this.sugarQuantity = sugarQuantity;
	}
	public Double getAdditiveQuantity(){
		return waterQuantity;
	}
	public void setAdditiveQuantity(Double additiveQuantity) {
		this.additiveQuantity = additiveQuantity;
	}
}
