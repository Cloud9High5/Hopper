import java.sql.Connection;
import java.sql.SQLException;
import java.sql.PreparedStatement;

public class NoteController {
	private NoteModel n;

	public NoteController(NoteModel n) {
		this.n = n;
	}
	
}

