import java.sql.Connection;
import java.sql.Date;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Scanner;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class NoteController {
	private NoteModel n;

	public NoteController(NoteModel n) {
		this.n = n;
	}
	public static int insertNote(NoteModel note) {
	    Connection conn = MyDBUtil.getConn();
	    int i = 0;
	    String sql = "insert into note (name,content,date) values(?,?,?)";
	    PreparedStatement pstmt;
	    try {
	        pstmt = (PreparedStatement) conn.prepareStatement(sql);
	        pstmt.setString(1, note.getName());
	        pstmt.setString(2, note.getContent());
	        pstmt.setDate(3, (Date) note.getDate());
	        i = pstmt.executeUpdate();
	        pstmt.close();
	        conn.close();
	    } catch (SQLException e) {
	        e.printStackTrace();
	    }
	    return i;
	}
	public static int updateNote(NoteModel note) {
	    Connection conn = MyDBUtil.getConn();
	    int i = 0;
	    String sql = "update note set content='" + note.getContent() + "' where name='" + note.getName() + "'";
	    PreparedStatement pstmt;
	    try {
	        pstmt = (PreparedStatement) conn.prepareStatement(sql);
	        i = pstmt.executeUpdate();
	        pstmt.close();
	        conn.close();
	    } catch (SQLException e) {
	        e.printStackTrace();
	    }
	    return i;
	}
	public static String[] getAllNote() {
	    Connection conn = MyDBUtil.getConn();
	    String sql = "select * from note";
	    String[] line = new String[100];
	    int i = 1;
	    PreparedStatement pstmt;
	    try {
	        pstmt = (PreparedStatement)conn.prepareStatement(sql);
	        ResultSet rs = pstmt.executeQuery();
	        int col = rs.getMetaData().getColumnCount();
	        int j = 0;
	        while (rs.next()) {
	        	String res = "";
        	    for (i = 1; i <= col; i++) {
        	    	System.out.print(rs.getString(i) + " | ");
        	    	res += rs.getString(i) + " | ";
	             }
        	    line[j++] = res;
        	    System.out.println();
	        }
	    } catch (SQLException e) {
	        e.printStackTrace();
	    }
	    return line;
	}
}

