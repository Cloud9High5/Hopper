
import java.util.ArrayList;

public class storageIngredient extends IngredientModel{
	public storageIngredient(String name, Double amount, String unit) {
		super(name, amount, unit);
		// TODO Auto-generated constructor stub
	}

	/*Double num;
	Double num2;
	ArrayList<Double> a =new ArrayList<Double>();
	ArrayList<String> n =new ArrayList<String>();
	//the two function below can only change amount base on the origin unit
	//add 
	public int addAmount(String name,Double amount) {
		
		if(super.updateAmount(name, super.getAmountbyName(name)+amount)==1) {
			
			return 1;
			
		}
		
		return 0;
		
	}
	
	//subtract
	public int subtractAmount(String name, Double amount) {
		
		this.num2= super.getAmountbyName(name);
		this.num =this.num2-amount;
		if(num <0&&this.num2 == 0.0) {			
								//check whether the name exist in the list or not
			return 1;
			
		}else if(num <0&&num2 != 0.0) {
			return 2;
		}				//check if the amount is too big
		if(super.updateAmount(name, num)==1) {
			
			return 1;
			
		}
		return 0;
	}
	
	//check
	public int checkEmpty() {
		a.clear();
		n.clear();
		if(super.getAmount(a)==1||super.getName(n)==1) {
			return 2;
		}

		int check =0;
		
		for(int i =n.size()-1 ;i>=0 ; i--) {
			
			if(a.get(i)==0.0) {
				check ++;
				super.deleteIngredient(n.get(i));
				
			}
			
		}
		
		return check;
	}*/
}
