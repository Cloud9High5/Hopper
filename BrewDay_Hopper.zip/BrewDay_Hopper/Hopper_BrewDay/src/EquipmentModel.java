import java.util.ArrayList;

public class EquipmentModel {
	private double capacity;
	private ArrayList<String> name;
	// construct object
	public EquipmentModel(ArrayList<String> name, float capacity) {
		this.capacity = capacity;
		this.name = name;
	}
	public ArrayList<String> getName() {
		return name;
	}
	public void setName(ArrayList<String> name) {
		this.name = name;
	}
	public double getCapacity() {
		return capacity;
	}
	public void setCap(float capacity) {
		this.capacity=capacity;
	}
}

