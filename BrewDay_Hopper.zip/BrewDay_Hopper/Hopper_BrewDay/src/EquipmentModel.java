import java.util.ArrayList;

public class EquipmentModel {
	private String capacity;
	private String name;
	private int Eid;
	// construct object
	public EquipmentModel(int Eid, String name, String capacity) {
		this.capacity = capacity;
		this.name = name;
		this.Eid = Eid;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getCapacity() {
		return capacity;
	}
	public void setCap(String capacity) {
		this.capacity=capacity;
	}
	public int getEid() {
		return Eid;
	}
	public void setEid(int Eid) {
		this.Eid = Eid;
	}
}

