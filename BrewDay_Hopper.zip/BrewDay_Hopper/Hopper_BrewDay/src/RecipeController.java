
public class RecipeController {
	private RecipeModel m;
	
}
