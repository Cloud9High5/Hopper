import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.Panel;
import java.awt.SystemColor;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.util.ArrayList;
import java.util.Date;

import javax.swing.AbstractListModel;
import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JEditorPane;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSpinner;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.ListModel;
import javax.swing.ScrollPaneConstants;
import javax.swing.SpinnerNumberModel;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;

public class RecipeView extends JFrame{
	private JPanel contentPane;
	private JTextField txtRecipeHere;
	private JTextField textField_1;
	/**
	 * Create the frame.
	 */
	DefaultListModel<String> listmodel = new DefaultListModel<String>() ;
	
	public RecipeView(RecipeModel m, RecipeController c) {
		setResizable(false);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setTitle("Recipe");
		setBounds(100, 100, 1048, 646);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel_1 = new JLabel("Recipe");
		lblNewLabel_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1.setForeground(Color.ORANGE);
		lblNewLabel_1.setFont(new Font("Bahnschrift", Font.BOLD | Font.ITALIC, 50));
		lblNewLabel_1.setBounds(279, 0, 484, 123);
		contentPane.add(lblNewLabel_1);
		
		Panel panel = new Panel();
		panel.setBounds(82, 150, 872, 354);
		contentPane.add(panel);
		panel.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Sample Size:");
		lblNewLabel.setBounds(123, 20, 153, 50);
		lblNewLabel.setForeground(SystemColor.textInactiveText);
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setFont(new Font("Bahnschrift", Font.BOLD, 23));
		panel.add(lblNewLabel);
		
		JLabel lblMinute = new JLabel("Minute:");
		lblMinute.setHorizontalAlignment(SwingConstants.CENTER);
		lblMinute.setForeground(SystemColor.textInactiveText);
		lblMinute.setFont(new Font("Bahnschrift", Font.BOLD, 17));
		lblMinute.setBounds(484, 38, 75, 15);
		panel.add(lblMinute);
		
		JLabel lblSecond = new JLabel("Second:");
		lblSecond.setHorizontalAlignment(SwingConstants.CENTER);
		lblSecond.setForeground(SystemColor.textInactiveText);
		lblSecond.setFont(new Font("Bahnschrift", Font.BOLD, 17));
		lblSecond.setBounds(484, 65, 75, 15);
		panel.add(lblSecond);
		
		JLabel lblHour = new JLabel("Hour:");
		lblHour.setForeground(SystemColor.textInactiveText);
		lblHour.setHorizontalAlignment(SwingConstants.CENTER);
		lblHour.setFont(new Font("Bahnschrift", Font.BOLD, 17));
		lblHour.setBounds(495, 10, 64, 15);
		panel.add(lblHour);
		
		textField_1 = new JTextField();
		textField_1.setBounds(285, 20, 78, 50);
		textField_1.setEditable(false);
		panel.add(textField_1);
		textField_1.setColumns(10);
		
		JLabel lblL = new JLabel("L");
		lblL.setBounds(374, 20, 40, 50);
		lblL.setHorizontalAlignment(SwingConstants.CENTER);
		lblL.setForeground(SystemColor.textInactiveText);
		lblL.setFont(new Font("Bahnschrift", Font.BOLD, 23));
		panel.add(lblL);
		
		JButton buttonBack = new JButton("Home");
		buttonBack.setFont(new Font("Bahnschrift", Font.BOLD, 14));
		buttonBack.setBounds(902, 559, 93, 23);
		contentPane.add(buttonBack);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
		scrollPane.setBounds(36, 96, 194, 112);
		panel.add(scrollPane);
		
		JList list_1 = new JList();
		list_1.setFont(new Font("Bahnschrift", Font.BOLD, 12));
		list_1.setModel(new AbstractListModel() {
			String[] values = new String[] {"example  0  kg", "example  0  kg", "example  0  kg", "example  0  kg", "example  0  kg", "example  0  kg", "example  0  kg", "example  0  kg", "example  0  kg", "example  0  kg", "example  0  kg", "example  0  kg", "example  0  kg"};
			public int getSize() {
				return values.length;
			}
			public Object getElementAt(int index) {
				return values[index];
			}
		});
		list_1.setSelectedIndex(-1);
		scrollPane.setViewportView(list_1);
		
		JLabel lblIngredient = new JLabel("Ingredient:");
		lblIngredient.setHorizontalAlignment(SwingConstants.CENTER);
		lblIngredient.setForeground(SystemColor.textInactiveText);
		lblIngredient.setFont(new Font("Bahnschrift", Font.BOLD, 17));
		lblIngredient.setBounds(36, 73, 93, 26);
		panel.add(lblIngredient);
		
		JLabel lblNote = new JLabel("Note:");
		lblNote.setHorizontalAlignment(SwingConstants.CENTER);
		lblNote.setForeground(SystemColor.textInactiveText);
		lblNote.setFont(new Font("Bahnschrift", Font.BOLD, 17));
		lblNote.setBounds(36, 208, 53, 26);
		panel.add(lblNote);
		
		JScrollPane scrollPane_1 = new JScrollPane();
		scrollPane_1.setBounds(41, 235, 789, 112);
		panel.add(scrollPane_1);
		
		JTextArea textArea = new JTextArea();
		scrollPane_1.setViewportView(textArea);
		
		JTextArea textArea1 = new JTextArea();
		textArea1.setBackground(new Color(240, 248, 255));
		textArea1.setBounds(235, 96, 492, 112);
		textArea1.setEditable(false);
		panel.add(textArea1);
		
		JButton btnAdd = new JButton("Add");
		btnAdd.setBounds(737, 107, 93, 23);
		panel.add(btnAdd);
		btnAdd.setFont(new Font("Bahnschrift", Font.BOLD, 12));
		
		JButton btnDelete = new JButton("Delete");
		btnDelete.setBounds(737, 142, 93, 23);
		panel.add(btnDelete);
		btnDelete.setFont(new Font("Bahnschrift", Font.BOLD, 12));
		
		JButton btnEdit = new JButton("Edit");
		btnEdit.setBounds(737, 178, 93, 23);
		panel.add(btnEdit);
		btnEdit.setFont(new Font("Bahnschrift", Font.BOLD, 12));
		
		JSpinner spinner = new JSpinner();
		spinner.setModel(new SpinnerNumberModel(0, 0, 24, 1));
		spinner.setBounds(557, 10, 40, 22);
		panel.add(spinner);
		
		JSpinner spinner_1 = new JSpinner();
		spinner_1.setModel(new SpinnerNumberModel(0, 0, 60, 1));
		spinner_1.setBounds(557, 37, 40, 22);
		panel.add(spinner_1);
		
		JSpinner spinner_2 = new JSpinner();
		spinner_2.setModel(new SpinnerNumberModel(0, 0, 60, 1));
		spinner_2.setBounds(557, 63, 40, 22);
		panel.add(spinner_2);
		
		//JList<String> list  = new JList<String>(listmodel);
		//JScrollPane listScroller = new JScrollPane(list);
		//listScroller.setBounds(375, 50, 120, 60);
		
		
		
		
		JButton btnConvert = new JButton("Convert");
		btnConvert.setFont(new Font("Bahnschrift", Font.BOLD, 19));
		btnConvert.setBounds(300, 510, 156, 51);
		contentPane.add(btnConvert);
		
		JButton btnCreate = new JButton("Create");
		btnCreate.setFont(new Font("Bahnschrift", Font.BOLD, 19));
		btnCreate.setBounds(580, 510, 156, 51);
		contentPane.add(btnCreate);
		//set visible
		this.setVisible(true);
		this.revalidate();
		buttonBack.addActionListener(new ActionListener() {
			private HomeModel hm;
			private HomeController hc;

			@Override
				public void actionPerformed(ActionEvent e) {
				 // Controller decides what the click means.
				dispose();
				new HomeView(hm, hc);
				}
			});
		btnAdd.addActionListener(new ActionListener() {
				
			@Override
				public void actionPerformed(ActionEvent e) {
				 // Controller decides what the click means.
				textArea1.append("1");
				}
			});
		btnEdit.addActionListener(new ActionListener() {
			
			
			
			private IngredientModel im = new IngredientModel(null, 0.0, null);
			private IngredientController ic =new IngredientController(im);
			
			@Override
				public void actionPerformed(ActionEvent e) {
				
				String s=(String)list_1.getSelectedValue();
				System.out.println(s); 
				
				if(s!=null) {
					String[] sa = s.split("  ");
					System.out.println(sa[0]); 
					im.setName(sa[0]);
					im.setAmount(Double.valueOf(sa[1]));
					im.setUnit(sa[2]);
				}
				
					
				 // Controller decides what the click means.
					new IngredientViewUpdate(im, ic);
				}
			});
		btnCreate.addActionListener(new ActionListener() {
			private RecipeModel rm;
			private RecipeController rc;

			@Override
				public void actionPerformed(ActionEvent e) {
				// Controller decides what the click means.
				//NoteController.insertNote(new NoteModel("note", textArea1.getText(), date));
				new RecipeViewCreate(rm, rc);
				}
			});
	}
	
}

