
public class EquipmentController {
	private EquipmentModel e;

	public EquipmentController(EquipmentModel e) {
		this.e = e;
	}
	
	public void addEquipment(String name){
		
	}
	
	public float updateCapacity(float newCapacity) {
		e.setCap(newCapacity);
		return newCapacity;
	}

}

