import java.sql.SQLException;
import java.sql.Connection;
import java.sql.ResultSet;

import com.mysql.jdbc.PreparedStatement;

public class EquipmentController {
	private EquipmentModel e;

	public EquipmentController(EquipmentModel e) {
		this.e = e;
	}
	
	public void addEquipment(String name){

	}
	
	public String updateCapacity(String newCapacity) {
		e.setCap(newCapacity);
		return newCapacity;
	}
	public static int insert(EquipmentModel eq) {
		Connection conn = MyDBUtil.getConn();
	    int i = 0;
	    String sql = "insert into equipment (Eid,Name,Capacity) values(?,?,?)";
	    PreparedStatement pstmt;
	    try {
	        pstmt = (PreparedStatement) conn.prepareStatement(sql);
	        pstmt.setInt(1, eq.getEid());
	        pstmt.setString(2, eq.getName());
	        pstmt.setString(3, eq.getCapacity());
	        i = pstmt.executeUpdate();
	        pstmt.close();
	        conn.close();
	    } catch (SQLException e) {
	        e.printStackTrace();
	    }
	    return i;
	}
	public static int update(EquipmentModel eq) {
		Connection conn = MyDBUtil.getConn();
	    int i = 0;
	    String sql = "update equipment set Capacity='" + eq.getCapacity() + "' where Eid='" + eq.getEid() + "'";
	    PreparedStatement pstmt;
	    try {
	        pstmt = (PreparedStatement) conn.prepareStatement(sql);
	        i = pstmt.executeUpdate();
	        System.out.println("resutl: " + i);
	        pstmt.close();
	        conn.close();
	    } catch (SQLException e) {
	        e.printStackTrace();
	    }
	    return i;
	}
	public static int delete(EquipmentModel eq) {
		Connection conn = MyDBUtil.getConn();
	    int i = 0;
	    String sql = "delete from equipment where Capacity='" + eq.getCapacity() + "'";
	    PreparedStatement pstmt;
	    try {
	        pstmt = (PreparedStatement) conn.prepareStatement(sql);
	        i = pstmt.executeUpdate();
	        System.out.println("resutl: " + i);
	        pstmt.close();
	        conn.close();
	    } catch (SQLException e) {
	        e.printStackTrace();
	    }
	    return i;
	}
	public static Integer getEquip() {
		Connection conn = MyDBUtil.getConn();
	    String sql = "select * from equipment";
	    PreparedStatement pstmt;
	    try {
	        pstmt = (PreparedStatement)conn.prepareStatement(sql);
	        ResultSet rs = pstmt.executeQuery();
	        int col = rs.getMetaData().getColumnCount();
	        System.out.println("============================");
	        while (rs.next()) {
	            for (int i = 1; i <= col; i++) {
	                System.out.print(rs.getString(i) + "\t");
	                if ((i == 2) && (rs.getString(i).length() < 8)) {
	                    System.out.print("\t");
	                }
	             }
	            System.out.println("");
	        }
	            System.out.println("============================");
	    } catch (SQLException e) {
	        e.printStackTrace();
	    }
	    return null;
	}

}

