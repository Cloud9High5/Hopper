import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.Panel;
import java.awt.SystemColor;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.util.ArrayList;

import javax.swing.AbstractListModel;
import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.ListModel;
import javax.swing.ScrollPaneConstants;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;

public class RecipeViewUpdate extends JFrame{
	private JPanel contentPane;
	private JTextField txtRecipeHere;
	private JTextField textField_1;
	/**
	 * Create the frame.
	 */
	DefaultListModel<String> listmodel = new DefaultListModel<String>() ;
	
	public RecipeViewUpdate(RecipeModel m, RecipeController c) {
		setResizable(false);
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setTitle("Update Recipe");
		setBounds(100, 100, 1048, 646);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		Panel panel = new Panel();
		panel.setBounds(82, 150, 872, 354);
		contentPane.add(panel);
		panel.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Sample Size:");
		lblNewLabel.setBounds(235, 20, 153, 50);
		lblNewLabel.setForeground(SystemColor.textInactiveText);
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setFont(new Font("Bahnschrift", Font.BOLD, 23));
		panel.add(lblNewLabel);
		
		textField_1 = new JTextField();
		textField_1.setBounds(397, 20, 78, 50);
		panel.add(textField_1);
		textField_1.setColumns(10);
		
		JLabel lblL = new JLabel("L");
		lblL.setBounds(486, 20, 40, 50);
		lblL.setHorizontalAlignment(SwingConstants.CENTER);
		lblL.setForeground(SystemColor.textInactiveText);
		lblL.setFont(new Font("Bahnschrift", Font.BOLD, 23));
		panel.add(lblL);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
		scrollPane.setBounds(36, 96, 194, 112);
		panel.add(scrollPane);
		
		JList list_1 = new JList();
		list_1.setFont(new Font("Bahnschrift", Font.BOLD, 12));
		list_1.setModel(new AbstractListModel() {
			String[] values = new String[] {"example", "example", "example", "example", "example", "example", "example", "example", "example", "example", "example", "example", "example"};
			public int getSize() {
				return values.length;
			}
			public Object getElementAt(int index) {
				return values[index];
			}
		});
		list_1.setSelectedIndex(-1);
		scrollPane.setViewportView(list_1);
		
		JLabel lblIngredient = new JLabel("Ingredient:");
		lblIngredient.setHorizontalAlignment(SwingConstants.CENTER);
		lblIngredient.setForeground(SystemColor.textInactiveText);
		lblIngredient.setFont(new Font("Bahnschrift", Font.BOLD, 17));
		lblIngredient.setBounds(36, 73, 93, 26);
		panel.add(lblIngredient);
		
		JLabel lblNote = new JLabel("Note:");
		lblNote.setHorizontalAlignment(SwingConstants.CENTER);
		lblNote.setForeground(SystemColor.textInactiveText);
		lblNote.setFont(new Font("Bahnschrift", Font.BOLD, 17));
		lblNote.setBounds(36, 208, 53, 26);
		panel.add(lblNote);
		
		JScrollPane scrollPane_1 = new JScrollPane();
		scrollPane_1.setBounds(41, 235, 789, 112);
		panel.add(scrollPane_1);
		
		JTextArea textArea = new JTextArea();
		scrollPane_1.setViewportView(textArea);
		
		JTextArea textArea1 = new JTextArea();
		textArea1.setBackground(new Color(240, 248, 255));
		textArea1.setBounds(235, 96, 492, 112);
		panel.add(textArea1);
		
		JButton btnAdd = new JButton("Add");
		btnAdd.setBounds(737, 107, 93, 23);
		panel.add(btnAdd);
		btnAdd.setFont(new Font("Bahnschrift", Font.BOLD, 12));
		
		JButton btnDelete = new JButton("Delete");
		btnDelete.setBounds(737, 142, 93, 23);
		panel.add(btnDelete);
		btnDelete.setFont(new Font("Bahnschrift", Font.BOLD, 12));
		
		JButton btnEdit = new JButton("Edit");
		btnEdit.setBounds(737, 178, 93, 23);
		panel.add(btnEdit);
		btnEdit.setFont(new Font("Bahnschrift", Font.BOLD, 12));
		
		JList<String> list  = new JList<String>(listmodel);
		JScrollPane listScroller = new JScrollPane(list);
		listScroller.setBounds(375, 50, 120, 60);
		
		JButton btnConvert = new JButton("Convert");
		btnConvert.setFont(new Font("Bahnschrift", Font.BOLD, 19));
		btnConvert.setBounds(300, 510, 156, 51);
		contentPane.add(btnConvert);
		
		JButton btnFinish = new JButton("Finish");
		btnFinish.setFont(new Font("Bahnschrift", Font.BOLD, 19));
		btnFinish.setBounds(580, 510, 156, 51);
		contentPane.add(btnFinish);
		
		//set visible
		this.setVisible(true);
		btnAdd.addActionListener(new ActionListener() {
				
			@Override
				public void actionPerformed(ActionEvent e) {
				 // Controller decides what the click means.
				textArea1.append("1");
				}
			});
		btnEdit.addActionListener(new ActionListener() {
			private IngredientModel im;
			private IngredientController ic;

			@Override
				public void actionPerformed(ActionEvent e) {
				 // Controller decides what the click means.
				new IngredientViewUpdate(im, ic);
				}
			});
		btnFinish.addActionListener(new ActionListener() {
			@Override
				public void actionPerformed(ActionEvent e) {
				 // Controller decides what the click means.
				dispose();
				}
			});
	}
	
}

