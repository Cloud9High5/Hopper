import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;

public class IngredientViewUpdate extends JFrame {
	private JTextField textField;
	private JTextField textField_1;
	private JPanel contentPane;
	private static final long serialVersionUID = 1L;
	public IngredientViewUpdate(IngredientModel m, IngredientController c) {
		setResizable(false);
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 571, 301);
		setTitle("Update Ingredient");
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JButton btnNewButton = new JButton("Finish");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				//update();
				dispose();
			}
		});
		
		textField = new JTextField();
		textField.setBounds(248, 79, 153, 23);
		contentPane.add(textField);
		textField.setColumns(10);
		btnNewButton.setBounds(417, 225, 93, 23);
		btnNewButton.setFont(new Font("Bahnschrift", Font.BOLD, 14));
		contentPane.add(btnNewButton);
		
		JLabel lblNewLabel = new JLabel("Rename:");
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setFont(new Font("Bahnschrift", Font.BOLD, 14));
		lblNewLabel.setBounds(178, 77, 66, 23);
		contentPane.add(lblNewLabel);
		
		JLabel lblNewCapcity = new JLabel("Amount:");
		lblNewCapcity.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewCapcity.setFont(new Font("Bahnschrift", Font.BOLD, 14));
		lblNewCapcity.setBounds(178, 127, 84, 23);
		contentPane.add(lblNewCapcity);
		
		textField_1 = new JTextField();
		textField_1.setColumns(10);
		textField_1.setBounds(255, 125, 39, 31);
		contentPane.add(textField_1);
		
		JLabel lblUnit = new JLabel("Unit:");
		lblUnit.setHorizontalAlignment(SwingConstants.CENTER);
		lblUnit.setFont(new Font("Bahnschrift", Font.BOLD, 14));
		lblUnit.setBounds(178, 172, 66, 23);
		contentPane.add(lblUnit);
		
		JComboBox comboBox = new JComboBox();
		comboBox.setModel(new DefaultComboBoxModel(new String[] {"L", "ML", "gal", "bbl", "cm\u00B3"}));
		comboBox.setBounds(248, 174, 66, 21);
		contentPane.add(comboBox);
		this.setVisible(true);
	}
}
